# data.py
# keep all my user datas
class WebApp_Data:
    url                 = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"
    dashboard_url       = "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index"
    reset_url           = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/requestPasswordResetCode"
    username            = "Admin"
    password            = "admin123"
    invalid_password    = "InvalidPassword"
    admin_Id            = "0038"
    admin_options       = ["User Management", "Job", "Organization", "Qualifications", "Nationalities", "Corporate Banking", "Configuration"]
    menu_items          = ["Admin", "PIM", "Leave", "Time", "Recruitment", "My Info", "Performance", "Dashboard", "Directory", "Maintenance", "Claim", "Buzz"]
